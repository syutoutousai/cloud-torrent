#!/bin/bash

echo "🚀 Starting CustomFlix Deployment on Debian..."

# 1. Update system and install Nginx
sudo apt update
sudo apt install -y nginx tar

# 2. Prepare directory
sudo mkdir -p /var/www/custom-flix
sudo cp -r dist/* /var/www/custom-flix/

# 3. Configure Nginx
sudo cp custom-flix.conf /etc/nginx/sites-available/custom-flix
sudo ln -sf /etc/nginx/sites-available/custom-flix /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

# 4. Set permissions
sudo chown -R www-data:www-data /var/www/custom-flix
sudo chmod -R 755 /var/www/custom-flix

# 5. Restart Nginx
sudo nginx -t && sudo systemctl restart nginx

echo "✅ Deployment Complete! Access your site at http://your-server-ip"
